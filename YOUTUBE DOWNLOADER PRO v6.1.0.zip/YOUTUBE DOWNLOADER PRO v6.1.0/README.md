# YOUTUBE DOWNLOADER PRO v6.1.0

Sistema de alta resiliência para download automatizado de áudio do YouTube, com processamento paralelo, recuperação automática de falhas e organização inteligente de arquivos.

Os downloads são convertidos automaticamente para **MP3 VBR 0**, com incorporação de capas, metadados oficiais e organização por artista.

---

## ✨ Principais Recursos

- Downloads paralelos para maior desempenho.
- Conversão automática para MP3 VBR 0.
- Incorporação de capas e metadados.
- Recuperação automática após interrupções.
- Prevenção de downloads duplicados.
- Cache inteligente de metadados.
- Detecção automática de cookies do navegador.
- Dashboard em tempo real no terminal.
- Relatórios automáticos em HTML, JSON e TXT.
- Organização automática dos arquivos por artista.

---

## 🛠️ Requisitos

Antes de começar, certifique-se de que os seguintes componentes estejam instalados:

- Python 3.12 ou superior
- FFmpeg instalado e disponível no `PATH`
- Conexão estável com a internet
- Espaço livre em disco suficiente

---

## 💻 Ambiente Recomendado

O programa pode ser executado em qualquer terminal compatível com Python. No entanto, recomendamos o uso de uma IDE para facilitar a instalação, atualização e manutenção.

### IDE recomendada

- PyCharm Community Edition

### Alternativas compatíveis

- Visual Studio Code
- Thonny
- IDLE

> **Recomendação:** Para usuários iniciantes, o PyCharm oferece a experiência mais simples, com gerenciamento automático do interpretador Python, terminal integrado e execução facilitada.

---

## 🚀 Instalação

### 1. Baixe os arquivos do projeto

Salve os seguintes arquivos em uma pasta dedicada:

```text
downloader.py
requirements.txt
README.md