#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
================================================================================
YOUTUBE DOWNLOADER PRO v6.1.0 (Production Core - Advanced Concurrency Engine)
================================================================================
Autor: Engenharia de Software / IA - Arquiteto de Sistemas Sênior
Descrição: Automação industrial para download de áudio em altíssima qualidade.
           Fusão entre o isolamento de ambiente completo e alta concorrência paralela.
================================================================================
"""

import os
import sys
import json
import time
import logging
import sqlite3
import shutil
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Tuple, Any, Optional

# ============================================================================
# 1. GERENCIAMENTO AUTOMÁTICO DE DEPENDÊNCIAS (Auto-Setup Core)
# ============================================================================
def garantir_dependencias_sistema() -> None:
    """Verifica e instala automaticamente as bibliotecas Python obrigatórias ausentes."""
    import subprocess
    dependencias = {
        "requests": "requests",
        "psutil": "psutil",
        "rich": "rich",
        "yt_dlp": "yt-dlp"
    }
    for modulo, pacote in dependencias.items():
        try:
            __import__(modulo)
        except ImportError:
            print(f"[Ambiente] Dependência crítica '{pacote}' ausente. Instalando automaticamente...")
            try:
                subprocess.check_call([sys.executable, "-m", "pip", "install", pacote])
            except Exception as e:
                print(f"[Erro Crítico] Falha ao instalar dependência '{pacote}': {e}")
                sys.exit(1)

# Executa o auto-setup antes de invocar os módulos do sistema
garantir_dependencias_sistema()

import requests
import psutil
import yt_dlp
import tkinter as tk
from tkinter import filedialog
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.live import Live
from rich.layout import Layout
from rich.prompt import Prompt

# Inst instanciação do terminal inteligente Rich
console = Console()
ARQUIVO_BOOT = Path(__file__).resolve().parent / "downloader_boot.json"

# ============================================================================
# 2. ISOLAMENTO ABSOLUTO DE DIRETÓRIOS (StorageCoordinator)
# ============================================================================
class StorageCoordinator:
    """Orquestra de forma resiliente a saúde e criação da árvore de diretórios operacionais."""
    
    def __init__(self, root_path: Path):
        self.root = root_path
        self.dirs: Dict[str, Path] = {
            "downloads": self.root / "Downloads",
            "logs": self.root / "Logs",
            "reports": self.root / "Reports",
            "backups": self.root / "Backups",
            "temp": self.root / "Temp",
            "database": self.root / "Database",
            "config": self.root / "Config"
        }

    def inicializar_estrutura(self) -> bool:
        """Garante a criação de todas as pastas essenciais do ecossistema."""
        for pasta in self.dirs.values():
            pasta.mkdir(parents=True, exist_ok=True)
            
        arquivo_playlists = self.dirs["config"] / "playlists.txt"
        if not arquivo_playlists.exists():
            with open(arquivo_playlists, "w", encoding="utf-8") as f:
                f.write("# ==========================================================================\n")
                f.write("# YOUTUBE DOWNLOADER PRO - LISTA DE PLAYLISTS OPERACIONAIS\n")
                f.write("# Formato Obrigatório: Nome do Artista|URL da Playlist ou Vídeo\n")
                f.write("# Linhas iniciadas com '#' são comentários e serão ignoradas automaticamente.\n")
                f.write("# ==========================================================================\n\n")
                f.write("# Imagine Dragons|https://www.youtube.com/playlist?list=PLw613M8C5o8tH8vKAdV17p6G7_38u5n1L\n")
            return False  # Indica que o arquivo foi recém-criado e está vazio
            
        # Avalia se há registros válidos no arquivo
        tem_conteudo = False
        with open(arquivo_playlists, "r", encoding="utf-8") as f:
            for linha in f:
                linha = linha.strip()
                if linha and not linha.startswith("#"):
                    tem_conteudo = True
                    break
        return tem_conteudo

    def obter_caminho_dir(self, chave: str) -> Path:
        return self.dirs.get(chave, self.root)

    def obter_subpastas_artista(self, artista: str) -> Dict[str, Path]:
        """Garante o isolamento individual por artista e higieniza caminhos inválidos."""
        artista_limpo = "".join([c for c in artista if c.isalnum() or c in " _-"]).strip().replace(" ", "_")
        if not artista_limpo:
            artista_limpo = "Artista_Desconhecido"
            
        base_artista = self.dirs["downloads"] / artista_limpo
        subpastas = {
            "mp3": base_artista / "MP3",
            "capas": base_artista / "Capas",
            "metadados": base_artista / "Metadados",
            "logs": base_artista / "Logs"
        }
        for sub in subpastas.values():
            sub.mkdir(parents=True, exist_ok=True)
        return subpastas

# ============================================================================
# 3. CONTROLE DE LOGS CENTRALIZADO
# ============================================================================
def inicializar_sistema_logs(logs_dir: Path) -> None:
    """Configura os 5 subsistemas de logs requeridos de forma isolada."""
    formatador = logging.Formatter('%(asctime)s - [%(levelname)s] - %(message)s')
    arquivos_log = {
        "sistema": "sistema.log",
        "downloads": "downloads.log",
        "erros": "erros.log",
        "eventos": "eventos.log",
        "atualizacoes": "atualizacoes.log"
    }
    for logger_nome, arquivo_nome in arquivos_log.items():
        logger = logging.getLogger(logger_nome)
        logger.setLevel(logging.INFO)
        if logger.handlers:
            logger.handlers.clear()
        handler = logging.FileHandler(logs_dir / arquivo_nome, encoding="utf-8")
        handler.setFormatter(formatador)
        logger.addHandler(handler)
        logger.propagate = False

# ============================================================================
# 4. ENGINE DE BANCO DE DADOS (SQLite Thread-Safe Checkpoints)
# ============================================================================
class DatabaseManager:
    """Camada de persistência relacional blindada contra concorrência via Thread-Safe."""
    
    def __init__(self, db_dir: Path):
        self.db_path = db_dir / "downloader_pro.db"
        self._criar_esquemas()

    def _conectar(self) -> sqlite3.Connection:
        return sqlite3.connect(str(self.db_path), check_same_thread=False, timeout=30)

    def _criar_esquemas(self) -> None:
        with self._conectar() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS execucoes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    data_inicio TEXT,
                    data_fim TEXT,
                    playlists_total INTEGER,
                    musicas_total INTEGER,
                    total_baixado INTEGER,
                    total_ignorado INTEGER,
                    total_erros INTEGER,
                    tempo_total_seg INTEGER,
                    navegador_cookies TEXT
                )
            """)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS playlists (
                    url TEXT PRIMARY KEY,
                    nome TEXT,
                    status TEXT,
                    ultima_atualizacao TEXT
                )
            """)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS musicas (
                    video_id TEXT PRIMARY KEY,
                    titulo TEXT,
                    artista TEXT,
                    caminho_arquivo TEXT,
                    tamanho_bytes INTEGER,
                    data_download TEXT,
                    status TEXT
                )
            """)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS erros (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    origem TEXT,
                    url TEXT,
                    mensagem TEXT,
                    data_erro TEXT
                )
            """)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS cache_metadata (
                    url TEXT PRIMARY KEY,
                    payload TEXT,
                    expira INTEGER
                )
            """)
            conn.commit()

    def registrar_execucao(self, data_ini: str, navegador: str) -> int:
        with self._conectar() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO execucoes (data_inicio, navegador_cookies, total_baixado, total_ignorado, total_erros)
                VALUES (?, ?, 0, 0, 0)
            """, (data_ini, navegador))
            conn.commit()
            return cursor.lastrowid

    def finalizar_execucao(self, exec_id: int, stats: dict, tempo_total: int) -> None:
        with self._conectar() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE execucoes
                SET data_fim = ?, playlists_total = ?, musicas_total = ?,
                    total_baixado = ?, total_ignorado = ?, total_erros = ?, tempo_total_seg = ?
                WHERE id = ?
            """, (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), stats['playlists'], stats['musicas'],
                  stats['baixado'], stats['ignorado'], stats['erros'], tempo_total, exec_id))
            conn.commit()

    def check_musica_baixada(self, video_id: str) -> bool:
        with self._conectar() as conn:
            cursor = conn.cursor()
            res = cursor.execute("SELECT status FROM musicas WHERE video_id = ?", (video_id,)).fetchone()
            return res is not None and res[0] == "BAIXADO"

    def registrar_musica(self, video_id: str, titulo: str, artista: str, caminho: Path, tamanho: int) -> None:
        with self._conectar() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR REPLACE INTO musicas (video_id, titulo, artista, caminho_arquivo, tamanho_bytes, data_download, status)
                VALUES (?, ?, ?, ?, ?, ?, 'BAIXADO')
            """, (video_id, titulo, artista, str(caminho), tamanho, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
            conn.commit()

    def registrar_erro(self, origem: str, url: str, msg: str) -> None:
        with self._conectar() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO erros (origem, url, mensagem, data_erro)
                VALUES (?, ?, ?, ?)
            """, (origem, url, msg, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
            conn.commit()

    def cache_get(self, url: str) -> Optional[List[Dict[str, Any]]]:
        with self._conectar() as conn:
            cursor = conn.cursor()
            res = cursor.execute("SELECT payload FROM cache_metadata WHERE url = ? AND expira > ?", (url, int(time.time()))).fetchone()
            return json.loads(res[0]) if res else None

    def cache_set(self, url: str, data: List[Dict[str, Any]], ttl_secs: int = 86400) -> None:
        expira = int(time.time()) + ttl_secs
        with self._conectar() as conn:
            cursor = conn.cursor()
            cursor.execute("INSERT OR REPLACE INTO cache_metadata (url, payload, expira) VALUES (?, ?, ?)", (url, json.dumps(data), expira))
            conn.commit()

# ============================================================================
# 5. GERENCIADOR DE COOKIES MULTINAVEGADOR AUTOMÁTICO
# ============================================================================
class CookieManager:
    """Extrai e testa de forma silenciosa e automatizada os cookies dos navegadores do usuário."""
    
    @staticmethod
    def detectar_cookies_disponiveis() -> Tuple[str, dict]:
        navegadores = ["chrome", "edge", "firefox", "brave", "opera", "safari"]
        logging.getLogger("sistema").info("Iniciando varredura e detecção de cookies ativos no sistema host...")
        
        for nav in navegadores:
            try:
                opts = {'cookiesfrombrowser': (nav, None, None, None), 'quiet': True, 'simulate': True}
                with yt_dlp.YoutubeDL(opts) as ydl:
                    # Carregamento sintático rápido para atestar acessibilidade de base de dados
                    pass
                logging.getLogger("sistema").info(f"Navegador '{nav.upper()}' selecionado com sucesso para bypass de cookies.")
                return nav, {'cookiesfrombrowser': (nav, None, None, None)}
            except Exception as e:
                logging.getLogger("sistema").debug(f"Cookies do navegador {nav} indisponíveis: {e}")
                
        logging.getLogger("sistema").warning("Nenhum cookie de navegador válido localizado. Operando em modo ANÔNIMO.")
        return "Modo Anônimo", {}

# ============================================================================
# 6. ROTINAS DE BACKUP DE SEGURANÇA INTEGRADOS
# ============================================================================
class BackupManager:
    """Realiza snapshots instantâneos pré e pós-processamento dos artefatos críticos."""
    
    @staticmethod
    def executar_backup(storage: StorageCoordinator, fase: str) -> None:
        backups_dir = storage.obter_caminho_dir("backups")
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        destino_zip = backups_dir / f"backup_sistema_{fase}_{timestamp}"
        
        try:
            temp_backup = storage.obter_caminho_dir("temp") / f"snapshot_{timestamp}"
            temp_backup.mkdir(parents=True, exist_ok=True)
            
            for pasta_alvo in ["Config", "Database", "Reports"]:
                origem = storage.root / pasta_alvo
                if origem.exists():
                    shutil.copytree(origem, temp_backup / pasta_alvo, dirs_exist_ok=True)
                    
            shutil.make_archive(str(destino_zip), 'zip', str(temp_backup))
            shutil.rmtree(temp_backup)
            logging.getLogger("sistema").info(f"Backup de segurança de [{fase}] concluído com sucesso.")
        except Exception as e:
            logging.getLogger("erros").error(f"Falha de barramento ao gerar backup de segurança [{fase}]: {e}")

# ============================================================================
# 7. GERENCIAMENTO DE MÚLTIPLOS ERROS E SAÚDE OPERACIONAL (HealthManager)
# ============================================================================
class HealthManager:
    """Supervisiona o barramento de rede, dependências estáticas e integridade de disco."""
    
    @staticmethod
    def verificar_disponibilidade_ffmpeg() -> Tuple[bool, str]:
        if shutil.which("ffmpeg") is not None:
            return True, "FFmpeg mapeado e ativo no PATH do sistema operacional."
        return False, "FFmpeg AUSENTE. A conversão final para MP3 e injeção de metadados falhará!"

    @staticmethod
    def avaliar_saude_sistema(storage: StorageCoordinator) -> Tuple[bool, List[str]]:
        alertas = []
        valido = True
        
        # Teste de Conexão Ativa
        try:
            requests.get("https://www.youtube.com", timeout=5)
        except Exception:
            alertas.append("Conexão instável com a Internet ou o YouTube está mitigando suas requisições.")
            valido = False
            
        # Espaço Livre em Disco
        try:
            _, _, livre = shutil.disk_usage(storage.root)
            livre_mb = livre / (1024 * 1024)
            if livre_mb < 500:
                alertas.append(f"Espaço crítico em disco: {livre_mb:.1f} MB disponíveis (Mínimo: 500MB).")
                valido = False
        except Exception as e:
            alertas.append(f"Incapaz de ler metadados do disco: {e}")
            
        # Permissões de escrita
        arquivo_teste = storage.root / "permissao_teste.tmp"
        try:
            with open(arquivo_teste, "w") as f: f.write("PRO")
            arquivo_teste.unlink()
        except Exception as e:
            alertas.append(f"Permissão de gravação negada no diretório raiz: {e}")
            valido = False
            
        # Validação do FFmpeg
        ff_status, ff_msg = HealthManager.verificar_disponibilidade_ffmpeg()
        if not ff_status:
            alertas.append(ff_msg)
            valido = False
            
        return valido, alertas

# ============================================================================
# 8. MONITOR DE MÉTRICAS OPERACIONAIS DO DASHBOARD
# ============================================================================
class DashboardMetrics:
    """Estrutura volátil thread-safe para armazenamento e leitura de telemetria em tempo real."""
    
    def __init__(self):
        self.lock = threading.Lock()
        self.playlist_atual = "Aguardando Inicialização..."
        self.musica_atual = "Aguardando alocação de tarefas..."
        self.total_baixado = 0
        self.total_ignorado = 0
        self.total_erros = 0
        self.velocidade_media = "0 KB/s"
        self.eta = "--:--"
        self.downloads_ativos: Dict[int, dict] = {}

    def atualizar_download_ativo(self, thread_id: int, titulo: str, percent: str, speed: str, eta: str) -> None:
        with self.lock:
            self.downloads_ativos[thread_id] = {
                "titulo": titulo, "percent": percent, "speed": speed, "eta": eta
            }

    def remover_download_ativo(self, thread_id: int) -> None:
        with self.lock:
            if thread_id in self.downloads_ativos:
                del self.downloads_ativos[thread_id]

def gerar_layout_interface(metrics: DashboardMetrics) -> Layout:
    """Gera dinamicamente a renderização assíncrona do terminal Rich."""
    layout = Layout()
    layout.split_column(
        Layout(name="header", size=3),
        Layout(name="body", ratio=1),
        Layout(name="footer", size=3)
    )
    
    layout["header"].update(Panel("[bold white]YOUTUBE DOWNLOADER PRO v6.1.0[/bold white] | Painel Operacional Avançado", style="bold bg:blue white", expand=True))
    
    with metrics.lock:
        pl_atual = metrics.playlist_atual
        mus_atual = metrics.musica_atual
        baixados = metrics.total_baixado
        ignorados = metrics.total_ignorado
        erros = metrics.total_erros
        vel = metrics.velocidade_media
        eta_g = metrics.eta
        ativos = list(metrics.downloads_ativos.values())
        
    cpu = psutil.cpu_percent()
    ram = psutil.virtual_memory().percent
    
    grid_corpo = Table.grid(expand=True)
    grid_corpo.add_column(ratio=1)
    grid_corpo.add_column(ratio=1)
    
    tabela_stats = Table(show_header=False, box=None, expand=True)
    tabela_stats.add_row("[bold cyan]Playlist em Foco:[/bold cyan]", pl_atual)
    tabela_stats.add_row("[bold cyan]Faixa Recente:[/bold cyan]", mus_atual)
    tabela_stats.add_row("[bold green]Total Baixado:[/bold green]", f"{baixados} faixas")
    tabela_stats.add_row("[bold yellow]Total Ignorado:[/bold yellow]", f"{ignorados} faixas (Checkpoints)")
    tabela_stats.add_row("[bold red]Total de Falhas:[/bold red]", f"{erros} erros")
    tabela_stats.add_row("[bold magenta]Velocidade Média:[/bold magenta]", vel)
    tabela_stats.add_row("[bold magenta]Tempo Restante Est.:[/bold magenta]", eta_g)
    
    tabela_pool = Table(title="Pool de Concorrência Ativo (Workers)", expand=True)
    tabela_pool.add_column("Título do Item", max_width=32, overflow="ellipsis")
    tabela_pool.add_column("Progresso")
    tabela_pool.add_column("Velocidade")
    tabela_pool.add_column("ETA")
    
    if ativos:
        for item in ativos:
            tabela_pool.add_row(item["titulo"], item["percent"], item["speed"], item["eta"])
    else:
        tabela_pool.add_row("[dim]Aguardando liberação de threads...[/dim]", "", "", "")
        
    grid_corpo.add_row(
        Panel(tabela_stats, title="Telemetria Analítica", border_style="cyan"),
        Panel(tabela_pool, title="Fila de Execução em Thread", border_style="green")
    )
    
    layout["body"].update(grid_corpo)
    layout["footer"].update(Panel(f"[bold white]Recursos Locais Host:[/bold white] Consumo de CPU: {cpu}% | Alocação de Memória RAM: {ram}% | Threads Concorrentes Limitadas a 3 Máximo", border_style="blue"))
    return layout

# ============================================================================
# 9. ENGINE DE DOWNLOAD E RESILIÊNCIA ANTI-BLOQUEIO
# ============================================================================
def hook_progresso_ytdlp(metrics: DashboardMetrics, thread_id: int, titulo_default: str):
    """Interfere nativamente nos callbacks do yt-dlp para alimentar o painel do Rich."""
    def callback(d: dict):
        if d['status'] == 'downloading':
            percent_cru = d.get('_percent_str', '0.0%').strip()
            percent = "".join([c for c in percent_cru if c.isdigit() or c in ".%"])
            if not percent.endswith("%"): percent += "%"
            
            vel_cru = d.get('speed')
            vel = f"{vel_cru / (1024 * 1024):.1f} MB/s" if vel_cru and vel_cru > 1024 * 1024 else (f"{vel_cru / 1024:.1f} KB/s" if vel_cru else "Calculando...")
            
            eta_cru = d.get('eta')
            eta = f"{int(eta_cru)//60:02d}:{int(eta_cru)%60:02d}" if eta_cru is not None else "--:--"
            
            arq = d.get('filename', '')
            titulo = Path(arq).stem if arq else titulo_default
            if " [" in titulo: titulo = titulo.split(" [")[0]
            
            metrics.atualizar_download_ativo(thread_id, titulo, percent, vel, eta)
        elif d['status'] == 'finished':
            metrics.remover_download_ativo(thread_id)
    return callback

def processar_download_video_worker(video: dict, artista: str, subpastas: dict, db: DatabaseManager, cookie_opts: dict, metrics: DashboardMetrics) -> None:
    """Unidade atômica concorrente despachada para o ThreadPoolExecutor."""
    video_id = video['id']
    url = video['url']
    titulo = video['title'] or f"Faixa {video_id}"
    
    # Validação Estrita do Checkpoint
    if db.check_musica_baixada(video_id):
        logging.getLogger("downloads").info(f"Checkpoint Ativo! Pulando vídeo já processado anteriormente: {titulo}")
        with metrics.lock:
            metrics.total_ignorado += 1
            metrics.musica_atual = f"[IGNORADO] {titulo}"
        return

    thread_id = threading.get_ident()
    logging.getLogger("eventos").info(f"Thread-{thread_id} iniciando download de: {titulo}")
    
    # Dicionário de diretivas nativas da API Python do yt-dlp
    ydl_opts = {
        'format': 'bestaudio/best',
        'paths': {
            'home': str(subpastas['mp3']),
            'temp': str(subpastas['logs']).replace("Logs", "Temp")
        },
        'outtmpl': '%(title)s.%(ext)s',
        'quiet': True,
        'no_warnings': True,
        'progress_hooks': [hook_progresso_ytdlp(metrics, thread_id, titulo)],
        'postprocessors': [
            {'key': 'FFmpegExtractAudio', 'preferredcodec': 'mp3', 'preferredquality': '0'},
            {'key': 'EmbedThumbnail'},
            {'key': 'FFmpegMetadata'}
        ],
        'writethumbnail': True
    }
    ydl_opts.update(cookie_opts)
    
    # Backoff Exponencial para mitigação de erros HTTP (403, 429) e quedas de DNS/Rede
    tentativa = 1
    max_tentativas = 3
    tempo_espera = 4
    
    while tentativa <= max_tentativas:
        try:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                ydl.download([url])
                
            # Registro de Sucesso e Mapeamento de Metadados locais do Artista
            logging.getLogger("downloads").info(f"Download e conversão executados com sucesso: {titulo}")
            db.registrar_musica(video_id, titulo, artista, subpastas['mp3'] / f"{titulo}.mp3", 0)
            
            # Organização e expurgo de thumbnails soltas na pasta de MP3
            try:
                for ext in ["*.jpg", "*.png", "*.webp", "*.jpeg"]:
                    for img in subpastas['mp3'].glob(ext):
                        shutil.move(str(img), subpastas['capas'] / img.name)
            except Exception:
                pass
                
            with metrics.lock:
                metrics.total_baixado += 1
                metrics.musica_atual = f"[CONCLUÍDO] {titulo}"
            return
            
        except Exception as e:
            msg_erro = str(e)
            logging.getLogger("erros").error(f"Falha de execução no item [{titulo}] - Tentativa {tentativa}/{max_tentativas}: {msg_erro}")
            db.registrar_erro("WorkerEngine", url, msg_erro)
            
            if "Private video" in msg_erro or "Video unavailable" in msg_erro:
                break # Erro permanente não sofre retry
                
            time.sleep(tempo_espera)
            tempo_espera *= 2
            tentativa += 1
            
    with metrics.lock:
        metrics.total_erros += 1
        metrics.musica_atual = f"[FALHA] {titulo}"

# ============================================================================
# 10. COMPILADOR ESTÁTICO DE RELATÓRIOS MULTIFORMATO
# ============================================================================
class ReportGenerator:
    """Gera automaticamente relatórios executivos em HTML, JSON e TXT estruturado."""
    
    @staticmethod
    def salvar_relatorios_consolidados(storage: StorageCoordinator, stats: dict, navegador: str) -> None:
        reports_dir = storage.obter_caminho_dir("reports")
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        tamanho_total = 0
        try:
            for item in storage.obter_caminho_dir("downloads").rglob("*"):
                if item.is_file(): tamanho_total += item.stat().st_size
        except Exception:
            pass
        tamanho_gb = tamanho_total / (1024 * 1024 * 1024)
        
        total_ops = stats['baixado'] + stats['ignorado'] + stats['erros']
        taxa = (stats['baixado'] / total_ops * 100) if total_ops > 0 else 100.0
        
        payload = {
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "duracao_segundos": stats['tempo_total'],
            "total_playlists": stats['playlists'],
            "total_musicas_mapeadas": stats['musicas'],
            "arquivos_baixados": stats['baixado'],
            "arquivos_ignorados": stats['ignorado'],
            "total_erros": stats['erros'],
            "espaco_disco_utilizado": f"{tamanho_gb:.3f} GB",
            "taxa_sucesso": f"{taxa:.1f}%",
            "cookies_origem": navegador
        }
        
        # 1. Emissão do Relatório JSON
        with open(reports_dir / f"relatorio_{timestamp}.json", "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=4, ensure_ascii=False)
            
        # 2. Emissão do Relatório TXT
        txt = f"=== RELATÓRIO DE EXECUÇÃO - YOUTUBE DOWNLOADER PRO v6.1.0 ===\n" \
              f"Data/Hora: {payload['timestamp']}\nDuração Total: {payload['duracao_segundos']}s\n" \
              f"Cookies Engine: {payload['cookies_origem']}\nTaxa de Sucesso: {payload['taxa_sucesso']}\n" \
              f"Espaço em Disco Ocupado: {payload['espaco_disco_utilizado']}\n" \
              f"Músicas Baixadas: {payload['arquivos_baixados']} | Ignoradas: {payload['arquivos_ignorados']} | Erros: {payload['total_erros']}\n"
        with open(reports_dir / f"relatorio_{timestamp}.txt", "w", encoding="utf-8") as f: f.write(txt)
        
        # 3. Emissão do Relatório HTML Executivo
        html = f"""<!DOCTYPE html><html><head><meta charset='utf-8'><title>Relatório Downloader Pro</title>
        <style>body{{font-family:Segoe UI,Arial;background:#f3f4f6;padding:30px;}} .box{{background:white;padding:25px;border-radius:8px;max-width:650px;margin:auto;box-shadow:0 4px 6px rgba(0,0,0,0.05);}}
        h2{{color:#1e3a8a;border-bottom:2px solid #e5e7eb;padding-bottom:10px;}} table{{width:100%;margin-top:15px;border-collapse:collapse;}} td,th{{padding:10px;border-bottom:1px solid #f3f4f6;text-align:left;}}</style></head>
        <body><div class='box'><h2>YOUTUBE DOWNLOADER PRO v6.1.0</h2><table>
        <tr><th>Métrica</th><th>Resultado</th></tr><tr><td>Data Execução</td><td>{payload['timestamp']}</td></tr>
        <tr><td>Taxa de Sucesso</td><td style='color:green;font-weight:bold;'>{payload['taxa_sucesso']}</td></tr>
        <tr><td>Total Baixado</td><td>{payload['arquivos_baixados']} faixas</td></tr>
        <tr><td>Total Ignorado</td><td>{payload['arquivos_ignorados']} faixas</td></tr>
        <tr><td>Erros do Sistema</td><td style='color:red;'>{payload['total_erros']}</td></tr>
        <tr><td>Espaço Consumido</td><td>{payload['espaco_disco_utilizado']}</td></tr>
        </table></div></body></html>"""
        with open(reports_dir / f"relatorio_{timestamp}.html", "w", encoding="utf-8") as f: f.write(html)

# ============================================================================
# 10. METADATA CACHE EXTRACTION ENGINE
# ============================================================================
def extrair_videos_playlist_com_cache(url: str, db: DatabaseManager, cookie_opts: dict) -> List[dict]:
    """Recupere as entries de forma ultra veloz através de persistência temporária local."""
    cache_local = db.cache_get(url)
    if cache_local:
        logging.getLogger("eventos").info(f"Metadados extraídos do cache SQLite para a URL: {url}")
        return cache_local
        
    opts = {'extract_flat': True, 'quiet': True, 'no_warnings': True}
    opts.update(cookie_opts)
    
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            res = ydl.extract_info(url, download=False)
            if not res: return []
            
            lista_videos = []
            if 'entries' in res:
                for entry in res['entries']:
                    if entry:
                        lista_videos.append({
                            'id': entry.get('id'),
                            'title': entry.get('title'),
                            'url': entry.get('url') or f"https://www.youtube.com/watch?v={entry.get('id')}"
                        })
            else:
                lista_videos.append({'id': res.get('id'), 'title': res.get('title'), 'url': url})
                
            db.cache_set(url, lista_videos, ttl_secs=86400) # Expiração automática de 24h
            return lista_videos
    except Exception as e:
        logging.getLogger("erros").error(f"Incapaz de extrair metadados da URL {url}: {e}")
        db.registrar_erro("MetadataEngine", url, str(e))
        return []

# ============================================================================
# 11. FLUXO PRINCIPAL E INTERACTION PRINCIPLE (Main Boot)
# ============================================================================
def main() -> None:
    tempo_inicio_global = time.time()
    
    # Validação e Seleção inteligente da pasta raiz do usuário
    diretorio_raiz: Optional[Path] = None
    if ARQUIVO_BOOT.exists():
        try:
            with open(ARQUIVO_BOOT, "r", encoding="utf-8") as f:
                dados_boot = json.load(f)
                pasta_salva = Path(dados_boot.get("last_root_dir", ""))
                if pasta_salva.exists():
                    console.print(Panel(f"[bold green]Diretório operacional recorrente detectado:[/bold green]\n{pasta_salva}", title="Inicialização Rápida"))
                    res = Prompt.ask("Deseja reutilizar este mesmo diretório?", choices=["S", "N"], default="S")
                    if res.upper() == "S":
                        diretorio_raiz = pasta_salva
        except Exception:
            pass

    if not diretorio_raiz:
        console.print("[yellow]Invocando seletor gráfico de arquivos... Selecione o diretório base para o sistema.[/yellow]")
        janela_tk = tk.Tk()
        janela_tk.withdraw()
        janela_tk.attributes('-topmost', True)
        selecao = filedialog.askdirectory(title="Selecione a Pasta de Destino Principal do Sistema")
        janela_tk.destroy()
        
        if not selecao:
            console.print("[bold red]Nenhum diretório selecionado. Abortando execução do sistema.[/bold red]")
            sys.exit(1)
        diretorio_raiz = Path(selecao)
        with open(ARQUIVO_BOOT, "w", encoding="utf-8") as f:
            json.dump({"last_root_dir": str(diretorio_raiz)}, f, indent=4)

    # Inicialização da malha estrutural de subpastas do ecossistema
    storage = StorageCoordinator(diretorio_raiz)
    possui_conteudo_operacional = storage.inicializar_estrutura()
    
    # Ativação imediata das malhas de logs e banco de dados
    inicializar_sistema_logs(storage.obter_caminho_dir("logs"))
    log_sys = logging.getLogger("sistema")
    log_sys.info("YOUTUBE DOWNLOADER PRO v6.1.0 inicializado com sucesso.")
    
    db = DatabaseManager(storage.obter_caminho_dir("database"))
    
    if not possui_conteudo_operacional:
        console.print(Panel(
            "[bold yellow]Ação Requerida:[/bold yellow] O arquivo [bold]playlists.txt[/bold] foi gerado de forma automatizada!\n\n"
            f"Caminho do Arquivo: [bold cyan]{storage.obter_caminho_dir('config') / 'playlists.txt'}[/bold cyan]\n\n"
            "Abra o arquivo, adicione seus links utilizando o caractere delimitador [bold]|[/bold] e execute o script novamente.\n"
            "Exemplo:\n[bold white]Nome do Artista|https://www.youtube.com/playlist?list=XXXX[/bold white]",
            title="Infraestrutura Criada com Sucesso!", border_style="yellow"
        ))
        sys.exit(0)

    # Execução automática de rotina pré-execução de backups de segurança
    BackupManager.executar_backup(storage, "PRE_RUN")

    # Auditoria de integridade ambiental do sistema host
    saude_ok, alertas = HealthManager.avaliar_saude_sistema(storage)
    if not saude_ok:
        console.print(Panel("\n".join([f"[red]• {a}[/red]" for a in alertas]), title="Falha Crítica na Auditoria de Saúde do Sistema", border_style="red"))
        sys.exit(1)

    # Mapeamento dinâmico de cookies nativos
    nav_cookies, cookie_opts = CookieManager.detectar_cookies_disponiveis()
    exec_id = db.registrar_execucao(datetime.now().strftime("%Y-%m-%d %H:%M:%S"), nav_cookies)

    # Leitura do arquivo estruturado Config/playlists.txt
    fila_trabalho: List[Tuple[str, str]] = []
    with open(storage.obter_caminho_dir("config") / "playlists.txt", "r", encoding="utf-8") as f:
        for linha in f:
            linha = linha.strip()
            if not linha or linha.startswith("#"): continue
            if "|" in linha:
                partes = linha.split("|", 1)
                fila_trabalho.append((partes[0].strip(), partes[1].strip()))

    metrics = DashboardMetrics()
    metrics.playlist_atual = "Mapeando Metadados..."
    
    total_videos_processar = []
    
    # Live Render Engine - Rich Terminal Dashboard Loop
    with Live(gerar_layout_interface(metrics), refresh_per_second=4) as live:
        # Etapa 1: Extração assíncrona inteligente e mapeamento de workloads
        for artista, url in fila_trabalho:
            logging.getLogger("eventos").info(f"Mapeando estrutura de links para o artista: {artista}")
            sub_dirs = storage.obter_subpastas_artista(artista)
            videos_extraidos = extrair_videos_playlist_com_cache(url, db, cookie_opts)
            for v in videos_extraidos:
                total_videos_processar.append((v, artista, sub_dirs))
                
        # Atualização global da volumetria inicial encontrada
        with metrics.lock:
            metrics.eta = "Calculando..."
            
        # Etapa 2: Disparo paralelo controlado via ThreadPoolExecutor (Limitado a 3 downloads simultâneos)
        with ThreadPoolExecutor(max_workers=3) as executor:
            futuros = []
            for video, artista, sub_dirs in total_videos_processar:
                futuros.append(executor.submit(processar_download_video_worker, video, artista, sub_dirs, db, cookie_opts, metrics))
                
            for _ in as_completed(futuros):
                # Força o refresh visual do painel a cada término de thread atômica
                live.update(gerar_layout_interface(metrics))
                
        metrics.playlist_atual = "Sessão Concluída!"
        metrics.musica_atual = "Aguardando encerramento..."

    # Coleta final de estatísticas de fechamento do sistema
    tempo_total_sessao = int(time.time() - tempo_inicio_global)
    stats_finais = {
        "playlists": len(fila_trabalho),
        "musicas": len(total_videos_processar),
        "baixado": metrics.total_baixado,
        "ignorado": metrics.total_ignorado,
        "erros": metrics.total_erros,
        "tempo_total": tempo_total_sessao
    }
    
    db.finalizar_execucao(exec_id, stats_finais, tempo_total_sessao)
    ReportGenerator.salvar_relatorios_consolidados(storage, stats_finais, nav_cookies)
    BackupManager.executar_backup(storage, "POS_RUN")
    
    console.print(Panel(f"[bold green]SESSÃO PROCESSADA COM SUCESSO COBRANDO EXCELÊNCIA OPERACIONAL![/bold green]\n"
                        f"Tempo de Execução: {tempo_total_sessao}s\n"
                        f"Relatórios disponíveis no diretório operacional 'Reports/'.", title="Fim de Execução"))

if __name__ == "__main__":
    main()